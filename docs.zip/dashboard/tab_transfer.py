"""Steps 2–4 · AutoML-Assisted Domain Divergence Audit, Transfer Benchmark & Validator Sign-Off.

Reads directly from acts_transfer.automl_runner.run_full_automl_for_granary so every step
renders immediately with 0-100% AutoML scores and zero sequential button locks.
"""
from __future__ import annotations
import plotly.graph_objects as go
import pandas as pd
import streamlit as st

from acts_transfer import governance as gov
from acts_transfer.automl_runner import run_full_automl_for_granary
from acts_transfer.causal_id import dml_estimate_and_refute, partition_causal_variables
from acts_transfer.diagnostics import compute_few_shot_scarcity, compute_weather_ablation, compute_weather_driver_attribution, gate_evidence      # pure functions: pytest calls the same code
from acts_transfer.methods import LABELS

import os
import re
import subprocess
import sys
import time
from pathlib import Path


# ------------------------------------------------------------------------------------------------
# Background refresh of ONE granary (runs pipeline/precompute_automl.py --only <granary> in a separate process while the user keeps browsing)
# ------------------------------------------------------------------------------------------------
_ROOT = Path(__file__).resolve().parent.parent                          # anchored to the project, so it works wherever Streamlit was started from
_REFRESH_SCRIPT = _ROOT / "pipeline" / "precompute_automl.py"
_REFRESH_LOCK_DIR = _ROOT / "results" / ".refresh_locks"
_REFRESH_PROCS: dict = {}                                               # granary -> Popen started by this server process (lets us reap a finished child)
_REFRESH_DONE: dict = {}                                                # granary -> (finished_at, exit code) of the last run this server process started
_REFRESH_CLEARED: dict = {}                                             # granary -> finished_at of the run whose results the shared cache was already reloaded for
_REFRESH_POLL_SECONDS = 3                                               # how often the page asks whether a running refresh has finished
_AUTOML_SESSION_KEYS = ("automl_summary", "tl_bundle", "tl_assessment", "tl_eval_results", "tl_choice", "tl_all_donor_ranking")


def _granary_lock_file(granary: str) -> Path:
    safe_name = "".join(c if c.isalnum() else "_" for c in granary)
    return _REFRESH_LOCK_DIR / f"{safe_name}.pid"


def _pid_alive(pid: int) -> bool:
    if os.name == "nt":
        out = subprocess.check_output(["tasklist", "/FI", f"PID eq {pid}"], stderr=subprocess.DEVNULL, text=True)
        return re.search(rf"(?<!\d){pid}(?!\d)", out) is not None         # a whole-number match: PID 12 must not match 120
    os.kill(pid, 0)                                                     # raises when there is no such process
    try:                                                                # a finished child that nobody has waited for is a zombie: it is not running
        with open(f"/proc/{pid}/status", encoding="utf-8") as f:
            if any(line.startswith("State:") and "Z" in line.split(":", 1)[1] for line in f):
                return False
    except OSError:
        pass                                                            # no /proc (macOS): fall through, the Popen handle below covers our own children
    return True


def _is_granary_refreshing(granary: str) -> bool:
    proc = _REFRESH_PROCS.get(granary)
    if proc is not None:                                                # our own child: poll() also reaps it, so it never lingers as a zombie
        if proc.poll() is None:
            return True
        _REFRESH_PROCS.pop(granary, None)
        _REFRESH_DONE[granary] = (time.time(), proc.returncode)
        _granary_lock_file(granary).unlink(missing_ok=True)
        return False
    lock_file = _granary_lock_file(granary)
    if not lock_file.exists():
        return False
    try:
        alive = _pid_alive(int(lock_file.read_text(encoding="utf-8").strip()))
    except Exception:
        alive = False
    if not alive:
        lock_file.unlink(missing_ok=True)
    return alive


def _start_background_granary_refresh(granary: str) -> None:
    if _is_granary_refreshing(granary):
        return
    _REFRESH_LOCK_DIR.mkdir(parents=True, exist_ok=True)
    log_path = _REFRESH_LOCK_DIR / "last_refresh.log"
    creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
    # --force: the button means "recompute", also when the stored result is current (without it the script reuses a current granary and does nothing)
    with open(log_path, "w", encoding="utf-8") as log_f:
        proc = subprocess.Popen(
            [sys.executable, str(_REFRESH_SCRIPT), "--only", granary, "--force"],
            stdout=log_f,
            stderr=subprocess.STDOUT,
            cwd=str(_ROOT),
            creationflags=creationflags,
            start_new_session=(os.name != "nt"),                        # survives a Streamlit restart
        )
    _REFRESH_PROCS[granary] = proc
    _granary_lock_file(granary).write_text(str(proc.pid), encoding="utf-8")


def _reload_cached_results() -> None:
    """drop every in-memory copy of the AutoML payload so the next run reads the file the refresh just wrote"""
    st.cache_data.clear()
    for k in _AUTOML_SESSION_KEYS:
        st.session_state.pop(k, None)


def _log_tail(n: int = 6) -> str:
    try:
        lines = (_REFRESH_LOCK_DIR / "last_refresh.log").read_text(encoding="utf-8", errors="replace").strip().splitlines()
        return "\n".join(lines[-n:])
    except OSError:
        return ""


def _drop_stale_results(granary: str) -> bool:
    """Reload the shared cache once for every run that ended cleanly, whichever browser session notices first (also when nobody had the page open at the time)."""
    done = _REFRESH_DONE.get(granary)
    if done and done[1] == 0 and _REFRESH_CLEARED.get(granary) != done[0]:
        _REFRESH_CLEARED[granary] = done[0]
        _reload_cached_results()
        return True
    return False


def _finish_refresh(granary: str, ran_here: bool = False) -> bool:
    """Called when a refresh is seen to be over. A refresh that ended cleanly reloads the results, so the page shows the new numbers without a click; a failed one keeps
    the old results and says why. The cache is reloaded once per run; each browser session is told about a finish once. Returns True when the page should rerun."""
    done = _REFRESH_DONE.get(granary)
    reloaded = _drop_stale_results(granary)
    if done is None:                                                    # a run this process holds no handle for (started before a restart): no exit code to read
        if not ran_here:
            return False
        _reload_cached_results()
        st.session_state["_refresh_msg"] = (granary, "success", f"Refresh finished for **{granary}**. The page now shows the new results.")
        return True
    seen = st.session_state.setdefault("_refresh_seen", {})
    if seen.get(granary) == done[0]:
        return reloaded
    seen[granary] = done[0]
    if done[1] == 0:
        st.session_state["_refresh_msg"] = (granary, "success", f"Refresh finished for **{granary}**. The page now shows the new results.")
    else:
        st.session_state["_refresh_msg"] = (granary, "error", f"The refresh for **{granary}** failed (exit code {done[1]}); the earlier results are still shown.\n\n```\n{_log_tail()}\n```")
    return True


@st.fragment(run_every=_REFRESH_POLL_SECONDS)
def _refresh_progress(granary: str) -> None:
    """Rendered only while a refresh runs. Every few seconds it asks whether the process has finished; when it has, the whole page reruns with the new results."""
    if _is_granary_refreshing(granary):
        st.info(f"Background refresh running for **{granary}** (~35-80 s). You can keep browsing or switch granary; "
                "the page updates by itself when it finishes.")
        return
    _finish_refresh(granary, ran_here=True)
    st.rerun()                                                          # app scope: the buttons and the results come back in their finished state


def render_refresh_controls(target_granary: str) -> None:
    """Two buttons that always stay: 'Refresh this granary' and 'Reload cached results'. Nothing else is shown until one is used; then a message box appears beside them
    (refresh running / finished / failed with the log, or results reloaded). While a refresh runs the page polls it by itself and reloads the results when it ends;
    'Reload cached results' stays as a manual fallback (for example after a refresh that was run from the command line)."""
    running = _is_granary_refreshing(target_granary)
    seen = st.session_state.setdefault("_refresh_seen", {})
    if target_granary not in seen:                                      # a session that opens the page later is not told about runs that ended before it came
        seen[target_granary] = (_REFRESH_DONE.get(target_granary) or (None,))[0]
    if not running and _finish_refresh(target_granary):
        st.rerun()                                                      # a refresh ended while the page was busy: show the new results now

    auto = st.session_state.get("automl_summary")
    older = isinstance(auto, dict) and bool(auto.get("stale_code"))
    refresh_help = "Recomputes only this granary in the background (~35-80 s) while you keep browsing."
    if older:
        refresh_help = "These results were built by an earlier version of the model code. " + refresh_help

    col_refresh, col_reload, col_msg = st.columns([1.3, 1.5, 3.2])
    with col_refresh:
        if st.button(
            "Refreshing..." if running else "Refresh this granary",
            key=f"btn_refresh_{target_granary}",
            disabled=running,
            help=refresh_help,
        ):
            _start_background_granary_refresh(target_granary)
            st.rerun()
    with col_reload:
        reload_clicked = st.button(
            "Reload cached results",
            key=f"btn_reload_cache_{target_granary}",
            disabled=running,                                           # reloading while the file is being written would only read the old one
            help="Re-reads the saved results (for example after refreshing from the command line).",
        )
    if reload_clicked:
        _reload_cached_results()
        st.session_state["_refresh_msg"] = (target_granary, "success", "Cached results reloaded.")
        st.rerun()

    with col_msg:                                                       # the message box next to the buttons: empty until a button has been used
        if running:
            _refresh_progress(target_granary)
        else:
            msg = st.session_state.get("_refresh_msg")
            if msg and msg[0] == target_granary:
                st.session_state.pop("_refresh_msg")
                (st.success if msg[1] == "success" else st.error)(msg[2])


def _get_automl_payload(D) -> dict:
    """Retrieve (or compute via @st.cache_data) the full AutoML & causal audit payload for the active granary."""
    target = st.session_state["granary"]
    if "automl_summary" in st.session_state and st.session_state["automl_summary"].get("target") == target:
        return st.session_state["automl_summary"]
    ds = D.DATA_DIR / "transfer_stage_dataset.csv"
    dy = D.DATA_DIR / "transfer_yield_dataset.csv"
    mtime = (ds if ds.exists() else dy).stat().st_mtime if (ds.exists() or dy.exists()) else 0.0
    auto = run_full_automl_for_granary(target, str(D.DATA_DIR), mtime, allow_stale=True)
    st.session_state["automl_summary"] = auto
    st.session_state["tl_bundle"] = auto["bundle"]
    st.session_state["tl_assessment"] = auto["assessment"]
    st.session_state["tl_eval_results"] = auto["eval_results"]
    st.session_state["tl_choice"] = auto["choice"]
    return auto


def _render_winner_cards(scores: dict):
    """Top 4 AutoML Winner KPI Cards (Donor Pool, Model, Feature Set, Scaling/Alignment)."""
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Best Donor Pool", scores["donor_winner"][0], f"Score: {scores['donor_winner'][1]:.1f}%")
    c2.metric("Best Model", scores["model_winner"][0], f"Score: {scores['model_winner'][1]:.1f}%")
    c3.metric("Best Feature Set", scores["feature_winner"][0], f"Score: {scores['feature_winner'][1]:.1f}%")
    c4.metric("Best Scaling / Alignment", scores["scaling_winner"][0], f"Score: {scores['scaling_winner'][1]:.1f}%")


# ------------------------------------------------------------------------------------------------
# STEP 2 · Causal Feature & Region Similarity Check (AutoML-Assisted)
# ------------------------------------------------------------------------------------------------
def render_domain_audit(D):
    target = st.session_state["granary"]
    auto = _get_automl_payload(D)
    scores = auto["scores"]
    donor_df = auto["donor_table"]
    asmt = auto["assessment"]

    # Locked Target indicator synced to sidebar
    c_tgt, c_pool = st.columns([1.2, 2.2])
    with c_tgt:
        st.selectbox(
            "Target Granary (locked to Selected Granary)",
            options=[target],
            index=0,
            disabled=True,
            key=f"locked_target_s2_{target}",
            help="Controlled by SELECTED GRANARY in the left navigation bar.",
        )
    with c_pool:
        st.info(
            f"**AutoML Domain & Causal Audit Active for {target}:** "
            f"All {len(donor_df)} other granaries were screened automatically. "
            f"Outliers with Domain AUC >= 0.90 are excluded from the transfer pool."
        )

    _render_winner_cards(scores)

    t_donors, t_causal, t_harm = st.tabs([
        "A. Donor Granary Similarity Scores (%)",
        "B. Causal Feature Identification & Refutation",
        "C. Harmonisation & Shift Diagnostics",
    ])

    with t_donors:
        st.markdown("**Pairwise Climate & Calendar Divergence Screen (0–100% Similarity Score)**")
        st.dataframe(donor_df, hide_index=True, width="stretch")

    with t_causal:
        ds = D.DATA_DIR / "transfer_stage_dataset.csv"
        dy = D.DATA_DIR / "transfer_yield_dataset.csv"
        y_df = pd.read_csv(ds if ds.exists() else dy)
        parts = partition_causal_variables(y_df)
        p1, p2, p3 = st.columns(3)
        p1.markdown(f"**Confounders ($X$):** `{', '.join(parts['X']) or 'n/a'}`")
        p2.markdown(f"**Actionable Practices ($T$):** `{', '.join(parts['T']) or 'n/a'}`")
        p3.markdown(f"**Mediators ($M$):** `{', '.join(parts['M']) or 'n/a'}`")

        t_choices = parts["T"] or ["C1_LSWI_rep"]
        chosen_t = st.selectbox("Inspect Double Machine Learning (DML) treatment lever", t_choices, key=f"dml_t_{target}")
        dml = dml_estimate_and_refute(y_df, treatment_col=chosen_t)
        m1, m2, m3 = st.columns(3)
        m1.metric("Deconfounded Effect (τ)", f"{dml['tau']:+.1f} kg/ha")
        m2.metric("Standard Error", f"±{dml['se']:.1f} kg/ha" if pd.notna(dml["se"]) else "n/a")
        m3.metric("Propensity Overlap Sample", f"{dml['n_overlap']} / {dml.get('n_total', dml['n_overlap'])}")
        if dml["refutations"]:
            ref_df = pd.DataFrame(dml["refutations"])
            ref_df["new_effect"] = ref_df["new_effect"].round(1)
            ref_df["passed"] = ref_df["passed"].map(lambda v: "PASS" if v else "CHECK")
            ref_df.columns = ["Refutation Check", "Refuted Effect (kg/ha)", "Status"]
            st.dataframe(ref_df, hide_index=True, width="stretch")

    with t_harm:
        st.markdown(f"**Overall Readiness Verdict:** `{getattr(asmt, 'verdict', 'READY')}`")
        diag = getattr(asmt, "summary", None)
        if isinstance(diag, pd.DataFrame) and len(diag):
            st.dataframe(diag, hide_index=True, width="stretch")
        else:
            st.write(f"Harmonised feature set ({len(auto['bundle'].features)} variables) validated with fold-safe RobustScaler and optical quality weights $w_t = \\max(0.2, \\text{{Optical\\_Valid\\_Fraction}}_t)$.")

    # Pre-checked AutoML configuration with optional manual override
    st.markdown("### Pipeline Configuration (Pre-Selected by AutoML)")
    override = st.toggle("Unlock manual override (default uses AutoML top-scoring configuration)", value=False, key=f"ov_s2_{target}")
    st.checkbox(
        f"Exclude climate/calendar outliers (Domain AUC ≥ 0.90) — **Score: {scores['donor_winner'][1]:.1f}%**",
        value=True,
        disabled=not override,
        key=f"chk_outlier_{target}",
    )
    st.checkbox(
        f"Use {scores['feature_winner'][0]} — **Score: {scores['feature_winner'][1]:.1f}%**",
        value=True,
        disabled=not override,
        key=f"chk_feat_{target}",
    )
    st.checkbox(
        f"Apply {scores['scaling_winner'][0]} — **Score: {scores['scaling_winner'][1]:.1f}%**",
        value=True,
        disabled=not override,
        key=f"chk_scale_{target}",
    )


# ------------------------------------------------------------------------------------------------
# STEP 3 · AutoML Model Training & Backtesting (Construct & Analyze)
# ------------------------------------------------------------------------------------------------
def render_benchmark_audit(D):
    target = st.session_state["granary"]
    auto = _get_automl_payload(D)
    scores = auto["scores"]
    choice = auto["choice"]
    eval_res = auto["eval_results"]

    _render_winner_cards(scores)

    st.markdown("### AutoML Transfer & Causal Model Leaderboard (0–100% Score)")
    st.dataframe(auto["model_table"], hide_index=True, width="stretch")

    t_fwd, t_loso, t_imp = st.tabs([
        "Expanding-Window Forward Validation (Primary)",
        "Leave-One-Season-Out (LOSO) Check",
        "Paired Improvement & Bootstrap CI",
    ])

    with t_fwd:
        fwd = eval_res.get("forward")
        if fwd is not None and len(fwd.metrics):
            m_df = fwd.metrics.copy()
            m_df["Method"] = m_df["method"].map(lambda m: LABELS.get(m, m))
            cols = [c for c in ("Method", "MAE", "RMSE", "R2", "n_test") if c in m_df.columns]
            st.dataframe(m_df[cols].round(4), hide_index=True, width="stretch")

    with t_loso:
        loso = eval_res.get("loso")
        if loso is not None and len(loso.metrics):
            l_df = loso.metrics.copy()
            l_df["Method"] = l_df["method"].map(lambda m: LABELS.get(m, m))
            cols = [c for c in ("Method", "MAE", "RMSE", "R2", "n_test") if c in l_df.columns]
            st.dataframe(l_df[cols].round(4), hide_index=True, width="stretch")

    with t_imp:
        if isinstance(choice.get("table"), pd.DataFrame) and len(choice["table"]):
            st.dataframe(choice["table"], hide_index=True, width="stretch")

    st.info(choice["statement"])


# ------------------------------------------------------------------------------------------------
# STEP 4 · Model Approval & Recommendation Check (Execute)
# ------------------------------------------------------------------------------------------------
def _evidence(auto, choice, gate_passed, method):
    """the evidence stored with a sign-off (what the Registry contents table and the KPKM views quote), in kg/ha, taken from the Step 3 results"""
    kg = float(getattr(auto["bundle"], "y_to_kg", 1.0))
    t = choice["table"]
    row = t[t["method"] == method]
    donors = auto["donor_table"]
    ev = dict(gate_passed=bool(gate_passed), model_key=method, model_label=LABELS.get(method, method) if method else "none",
              source=", ".join(donors[donors["Status"] == "Included"]["Donor Granary"]), validation="forward validation (expanding window)",
              token=choice.get("token"), automl_scores=auto["scores"])
    if len(row):
        r = row.iloc[0]
        ev.update(delta_nt=float(r["Delta_NT (RMSE)"]), delta_nt_kg_ha=float(r["Delta_NT (RMSE)"]) * kg, baseline=r["Delta_NT baseline"],
                  domain_ok=bool(r["Criterion 1 domain relevance"]), seasons_compared=int(r["seasons compared"]),
                  statistically_supported=bool(r["statistically supported"]),
                  rmse_common_kg_ha={k: float(v) * kg for k, v in r["RMSE vs all baselines (common seasons)"].items()})
        ge = gate_evidence(auto, method)
        if ge.get("available"):
            ev["evidence_criteria"] = {k: ge[k] for k in ("c0_delta_nt_negative", "c1_lower_mae", "c2_interval_excludes_zero", "c3_loso_win", "c4_enough_seasons", "domain_ok",
                                                         "held_out_seasons", "min_seasons", "mae_change_kg_ha", "ci95_low_kg_ha", "ci95_high_kg_ha", "best_baseline", "strength", "reason",
                                                         "nested_delta_nt_kg_ha", "nested_method", "nested_ok", "nested_gate")}
    return ev


def _record_decision(D, auto, choice, target, decision, who, notes, gate_passed):
    """record a sign-off together with the real forecast tables (backtest, nowcast, 2025-2028 outlook per scenario) the KPKM pages read; nothing is recorded if they cannot be built"""
    from acts_transfer.publish import build_published_from_automl
    from acts_transfer.sweep import clean_physical_ranges
    ds, dy = D.DATA_DIR / "transfer_stage_dataset.csv", D.DATA_DIR / "transfer_yield_dataset.csv"
    Y, _ = clean_physical_ranges(pd.read_csv(str(ds if ds.exists() else dy)))
    method = choice["selected"] if decision == "APPROVE" else (choice.get("best_transfer") or choice["selected"])
    try:
        published = build_published_from_automl(auto, Y, target)
        return gov.record_signoff(target, decision, who or "Validator", notes, _evidence(auto, choice, gate_passed, method), published)
    except Exception as ex:      # a sign-off without forecast tables would show a verified badge over a baseline forecast, so nothing is saved
        st.error(f"The sign-off was not recorded because the forecast tables could not be built: {ex}")
        return None


def render_preapproval_diagnostics(bundle, kg: float):
    """Three evidence views shown right above the Approve / Reject buttons. Each is computed by a pure function in acts_transfer.diagnostics, so the numbers
    here are exactly what the pytest regression checks. Nothing here changes the gate: it is context for the validator."""
    st.markdown("#### Pre-approval diagnostics: does the weather signal earn its place?")

    # (a) weather-feature ablation
    ab = compute_weather_ablation(bundle, kg)
    st.markdown("**(a) Weather-feature ablation** (forward validation: real weather / satellite inputs vs. zeroed anomalies)")
    if ab["n_folds"] == 0 or pd.isna(ab["weather_gain"]):
        st.info("Not enough earlier seasons to run the ablation (at least 3 target seasons are needed).")
    else:
        gain = float(ab["weather_gain"])
        a1, a2, a3 = st.columns(3)
        a1.metric("Error with real weather", f"{ab['err_real']:,.0f} kg/ha")
        a2.metric("Error with zeroed anomalies", f"{ab['err_ablated']:,.0f} kg/ha")
        a3.metric("Saved by real weather", f"{gain:+,.0f} kg/ha", "weather helps" if gain > 0 else "weather does not help", delta_color="normal" if gain > 0 else "inverse")
        if gain <= 0:
            st.warning(f"Over {ab['n_folds']} held-out seasons the forecasts were no better with the real weather and satellite inputs than with an average season. "
                       "A transfer model that leans on these inputs is not supported by this evidence, whatever the safeguard gate says.")
        else:
            st.caption(f"RMSE over {ab['n_folds']} held-out seasons; {len(ab['weather_features'])} weather / satellite features; only the held-out season's inputs differ between the two runs.")

    # (b) few-shot data scarcity
    fs = compute_few_shot_scarcity(bundle, kg, shots=(2, 3, 4))
    st.markdown("**(b) Few-shot data scarcity** (forecast error when the target granary has only n seasons of history)")
    if fs.empty:
        st.info("Not enough target seasons for the few-shot comparison.")
    else:
        st.dataframe(fs, hide_index=True, width="stretch", column_config={
            "Local-Only Error (kg/ha)": st.column_config.NumberColumn(format="%.0f"),
            "Transfer Error (kg/ha)": st.column_config.NumberColumn(format="%.0f"),
            "Transfer Advantage": st.column_config.NumberColumn("Transfer Advantage (kg/ha, + = transfer better)", format="%+.0f"),
            "Test Seasons": st.column_config.NumberColumn(format="%d")})
        st.caption("All rows are scored on the same held-out seasons. Each forecast uses only the n most recent earlier target seasons and donor seasons that came before it.")

    # (c) weather / satellite driver attribution
    dr = compute_weather_driver_attribution(bundle, kg, top_k=6)
    st.markdown("**(c) Top weather / satellite drivers** (yield change in kg/ha for a +1 SD shift of the driver)")
    if dr.empty:
        st.info("No weather or satellite drivers are available for attribution.")
    else:
        d = dr.iloc[::-1]                                              # largest at the top of a horizontal bar chart
        fig = go.Figure(go.Bar(x=d["Impact (kg/ha per +1 SD)"], y=d["Driver"], orientation="h",
                               marker_color=["#2ca02c" if v >= 0 else "#d62728" for v in d["Impact (kg/ha per +1 SD)"]],
                               hovertemplate="%{y}: %{x:+,.0f} kg/ha per +1 SD<extra></extra>"))
        fig.update_layout(xaxis_title="Yield change per +1 SD shift (kg/ha)", yaxis_title=None, height=60 + 42 * len(d), margin=dict(t=10, b=10, l=10, r=10))
        st.plotly_chart(fig, width="stretch")
        st.caption("Descriptive, not causal: correlated drivers share their effect, and each slope comes from only a few seasons.")


def render_gate_evidence(ge: dict, gate_passed: bool) -> None:
    """The four evidence criteria behind the safeguard gate, in the words the code uses, and a warning when the gate passed on thin evidence.
    Display only: it changes neither the gate nor the sign-off buttons."""
    st.markdown("#### Evidence behind the gate")
    if not ge.get("available"):
        st.info("No transfer candidate was evaluated, so there is no evidence to show.")
        return
    mark = lambda ok: "✅" if ok else "❌"                                                # noqa: E731
    ci = (f"{ge['ci95_low_kg_ha']:+,.0f} to {ge['ci95_high_kg_ha']:+,.0f} kg/ha (mean {ge['mae_change_kg_ha']:+,.0f})"
          if pd.notna(ge["ci95_low_kg_ha"]) else f"not testable: {ge['held_out_seasons']} paired season(s)")
    rows = [
        ("0", "Safeguard gate: Δ_NT < 0 against the best local baseline", mark(ge["c0_delta_nt_negative"]), f"{ge['delta_nt_kg_ha']:+,.1f} kg/ha vs {ge['delta_nt_baseline']}"),
        ("1", f"Lower MAE than the best baseline ({ge['best_baseline']}; the best of all six, donor-trained ones included)", mark(ge["c1_lower_mae"]), ""),
        ("2", "95% interval of the error change excludes zero", mark(ge["c2_interval_excludes_zero"]), ci),
        ("3", "Also better under leave-one-season-out", mark(ge["c3_loso_win"]), ""),
        ("4", f"At least {ge['min_seasons']} held-out seasons", mark(ge["c4_enough_seasons"]), f"{ge['held_out_seasons']} paired ({ge['common_seasons']} common to all baselines)"),
        ("-", "Agro-climatic domain compatible with the donors", mark(ge["domain_ok"]), ""),
        ("-", "Nested check: method chosen on the earlier seasons, Δ_NT < 0 on the later ones" + (" (a gate condition)" if ge.get("nested_gate") else " (shown only)"),
         mark(ge["nested_ok"]) if ge.get("nested_available") else "—",
         (f"{ge['nested_delta_nt_kg_ha']:+,.1f} kg/ha with {LABELS.get(ge['nested_method'], ge['nested_method'])}; chosen on {ge['nested_select_seasons']} seasons, judged on {ge['nested_hold_seasons']}"
          if ge.get("nested_available") else f"too few seasons ({ge.get('nested_hold_seasons', 0)} later)")),
    ]
    st.dataframe(pd.DataFrame(rows, columns=["#", "Criterion", "Met", "Measured"]), hide_index=True, width="stretch")
    if gate_passed and ge["strength"] == "supported":
        st.success("The gate passed and the improvement is statistically supported.")
    elif gate_passed:
        st.warning(f"**The gate passed, but the evidence is thin:** {ge['reason']} Δ_NT < 0 is a safety check, not proof that transfer improves the forecast. "
                   "Approve only with ground verification, or record the local baseline.")
    else:
        st.info("The safeguard gate triggered, so the local baseline is the model of record. The evidence above is shown for reference.")
    if gate_passed and ge.get("nested_available") and not ge["nested_ok"]:
        st.warning(f"**Selection check failed:** choosing the method on the earlier seasons only, it would have been {ge['nested_delta_nt_kg_ha']:+,.0f} kg/ha worse than the best local baseline on the later "
                   "seasons. Part of the gain above may be luck from picking the best of several candidates on the same seasons it is judged on.")


def render_validator_signoff(D):
    target = st.session_state["granary"]
    auto = _get_automl_payload(D)
    scores = auto["scores"]
    choice = auto["choice"]
    sg = choice["safeguard"]
    gate_passed = bool(sg.get("gate_passed", False))
    kg = float(getattr(auto["bundle"], "y_to_kg", 1000.0))

    _render_winner_cards(scores)

    st.markdown("### Pre-Approval Validation: Donor Pool & Weather Outlook")

    # 1. Single-Donor vs. Pooled-Donor Competition Table
    if "donor_pool_table" in auto and not auto["donor_pool_table"].empty:
        st.markdown("**1. Donor Pool Size Competition (Single Closest Donor vs. Pooled)**")
        st.dataframe(auto["donor_pool_table"], width="stretch", hide_index=True)

    # 2. Pre-Approval Out-of-Sample Outlook Chart (Before Publishing to Manager Site)
    st.markdown("**2. Pre-Approval Yield Outlook vs. Same-as-Last-Year Baseline**")
    win_method_id = str(auto["model_table"].iloc[0]["Method ID"])
    pred_df = auto["eval_results"]["forward"].predictions
    sub_pred = pred_df[pred_df["method"].isin([win_method_id, "persistence"])].copy()

    if not sub_pred.empty:
        piv = sub_pred.pivot(index="group", columns="method", values="y_pred") * kg
        actuals = sub_pred[sub_pred["method"] == win_method_id].set_index("group")["y_true"] * kg

        rmse_model = float(((piv[win_method_id] - actuals) ** 2).mean() ** 0.5) if win_method_id in piv else float("nan")
        rmse_pers = float(((piv["persistence"] - actuals) ** 2).mean() ** 0.5) if "persistence" in piv else float("nan")
        delta_kg = rmse_model - rmse_pers

        c1, c2, c3 = st.columns(3)
        c1.metric("Pre-Approval Model RMSE", f"{rmse_model:,.0f} kg/ha", f"{delta_kg:+,.0f} kg/ha vs Persistence", delta_color="inverse")
        c2.metric("Same-as-Last-Year RMSE", f"{rmse_pers:,.0f} kg/ha")
        c3.metric("Safeguard Gate", "PASS" if gate_passed else "FALLBACK")

        fig = go.Figure()
        fig.add_trace(go.Scatter(x=actuals.index, y=actuals.values, mode="lines+markers", name="Actual Yield (kg/ha)", line=dict(color="#1f77b4", width=3)))
        if win_method_id in piv.columns:
            fig.add_trace(go.Scatter(x=piv.index, y=piv[win_method_id], mode="lines+markers", name=f"Candidate Outlook ({LABELS.get(win_method_id, win_method_id)})", line=dict(color="#2ca02c", width=2, dash="dash")))
        if "persistence" in piv.columns:
            fig.add_trace(go.Scatter(x=piv.index, y=piv["persistence"], mode="lines+markers", name="Same as Last Year (Persistence)", line=dict(color="#7f7f7f", width=2, dash="dot")))
        fig.update_layout(xaxis_title="Season Year", yaxis_title="Yield (kg/ha)", height=350, margin=dict(t=20, b=20))
        st.plotly_chart(fig, width="stretch")

    st.markdown("### Negative-Transfer Safeguard Gate & Governance Decision")
    g1, g2, g3 = st.columns(3)
    g1.metric("Candidate Transfer Winner", LABELS.get(choice.get("best_transfer", ""), str(choice.get("best_transfer", "n/a"))))
    d_nt = sg.get("delta_nt")
    g2.metric("Δ_NT (RMSE vs Local Baseline)", f"{d_nt:+.3f} t/ha" if d_nt is not None and pd.notna(d_nt) else "n/a")
    g3.metric("Safeguard Gate Status", "PASS (Δ_NT < 0)" if gate_passed else "TRIGGERED (Local Fallback)")

    st.write(choice["statement"])

    reg = gov.load()
    cur_entry = gov.effective(target, reg)
    st.caption(f"Current registry status for **{target}**: `{cur_entry['status']}`")

    ev_method = choice["selected"] if gate_passed and choice.get("transfer_supported") else choice.get("best_transfer")
    render_gate_evidence(gate_evidence(auto, ev_method), gate_passed)    # the four criteria and a warning when the gate passed on thin evidence

    render_preapproval_diagnostics(auto["bundle"], kg)                  # (a) ablation, (b) few-shot scarcity, (c) driver attribution: directly above the sign-off controls

    c_v1, c_v2 = st.columns([1, 2])
    validator_name = c_v1.text_input("Validator Name / Role", value="Model Validator", key="so_name")
    notes = c_v2.text_input("Governance & Audit Notes", placeholder="Optional sign-off note for KPKM Programme Manager", key="so_notes")

    b_app, b_rej = st.columns(2)
    with b_app:
        if st.button(
            "✅ Approve Transfer Model for KPKM Workspace",
            key="so_approve",
            disabled=not gate_passed,
            width="stretch",
        ):
            if _record_decision(D, auto, choice, target, "APPROVE", validator_name, notes, True) is None:
                return
            st.success(f"Approved **{LABELS.get(choice['selected'], choice['selected'])}** for **{target}**.")
            st.rerun()

    with b_rej:
        if st.button(
            "🛡️ Record Local Baseline Fallback (Reject Transfer)",
            key="so_reject",
            width="stretch",
        ):
            if _record_decision(D, auto, choice, target, "REJECT", validator_name, notes, gate_passed) is None:
                return
            st.warning(f"Recorded Local Baseline Fallback (**{LABELS.get(choice['reference'], choice['reference'])}**) for **{target}**.")
            st.rerun()